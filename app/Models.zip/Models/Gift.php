<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gift extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'quantity'
    ];

    protected $cast = [
        'name'           => 'string',
        'description'    => 'boolean',
        'quantity'       => 'integer'
    ];
}
